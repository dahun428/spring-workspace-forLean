package com.sample.web.view;

import java.util.Date;

public class Reserve {
    private int id;
    private User reserveUser;
    private Performance performance;
    private Date regDate;
    private String status;
    private String receiveType;
    private Mate mate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getReserveUser() {
        return reserveUser;
    }

    public void setReserveUser(User reserveUser) {
        this.reserveUser = reserveUser;
    }

    public Performance getPerformance() {
        return performance;
    }

    public void setPerformance(Performance performance) {
        this.performance = performance;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReceiveType() {
        return receiveType;
    }

    public void setReceiveType(String receiveType) {
        this.receiveType = receiveType;
    }

    public Mate getMate() {
        return mate;
    }

    public void setMate(Mate mate) {
        this.mate = mate;
    }
    

}