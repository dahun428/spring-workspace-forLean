package com.sample.web.view;

import java.util.List;

public class Mate {
    private int id;
    private Performance performance;
    private String seatGroup;
    private String category;
    private int groupsize;
    private String seatRate;
    private List<User> mateMembers;
    private List<MateTag> mateTags;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
   

	public Performance getPerformance() {
		return performance;
	}

	public void setPerformance(Performance performance) {
		this.performance = performance;
	}

	public String getSeatGroup() {
        return seatGroup;
    }

    public void setSeatGroup(String seatGroup) {
        this.seatGroup = seatGroup;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getGroupsize() {
        return groupsize;
    }

    public void setGroupsize(int groupsize) {
        this.groupsize = groupsize;
    }

    public String getSeatRate() {
        return seatRate;
    }

    public void setSeatRate(String seatRate) {
        this.seatRate = seatRate;
    }

    public List<User> getMateMembers() {
        return mateMembers;
    }

    public void setMateMembers(List<User> mateMembers) {
        this.mateMembers = mateMembers;
    }

	public List<MateTag> getMateTags() {
		return mateTags;
	}

	public void setMateTags(List<MateTag> mateTags) {
		this.mateTags = mateTags;
	}
    

   
    
}   