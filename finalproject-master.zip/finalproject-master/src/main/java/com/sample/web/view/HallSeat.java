package com.sample.web.view;

public class HallSeat {
    private HallInfo hall;
    private String row;
    private String no;
    private String rate;
    private String status;
    private Mate mate;

    public HallInfo getHall() {
        return hall;
    }

    public void setHall(HallInfo hall) {
        this.hall = hall;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Mate getMate() {
        return mate;
    }

    public void setMate(Mate mate) {
        this.mate = mate;
    }

    
}