package com.sample.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 
 * @author semin
 *
 */
@Controller
@RequestMapping("/qna")
public class QnAController {
	
	
	@GetMapping("/list.do")
	public String list(Model model) {
		
		return "qna/list";
	}
}
