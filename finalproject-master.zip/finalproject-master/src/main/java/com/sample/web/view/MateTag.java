package com.sample.web.view;

public class MateTag {

	private int mateId;
	private String tagName;
	
	public MateTag() {
	}

	public int getMateId() {
		return mateId;
	}

	public void setMateId(int mateId) {
		this.mateId = mateId;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	@Override
	public String toString() {
		return "MateTag [mateId=" + mateId + ", tagName=" + tagName + "]";
	}

	
}
