package com.sample.web.form;

import java.util.List;

public class NoticeForm {
	
	private String category;
	private String title;
	private String content;
	private int badge;
	private List<String> imagePath;
	
	public NoticeForm() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public List<String> getImagePath() {
		return imagePath;
	}

	public void setImagePath(List<String> imagePath) {
		this.imagePath = imagePath;
	}
	
	public int getBadge() {
		return badge;
	}

	public void setBadge(int badge) {
		this.badge = badge;
	}

	@Override
	public String toString() {
		return "NoticeForm [category=" + category + ", title=" + title + ", content=" + content + ", imagePath="
				+ imagePath + "]";
	}

}
