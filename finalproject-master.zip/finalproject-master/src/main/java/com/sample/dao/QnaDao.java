package com.sample.dao;

import java.util.List;

import com.sample.web.view.Qna;

public interface QnaDao {
    void insertQna(Qna qna);
    void updateQna(Qna qna);
    List<Qna> getAllQnas();
    Qna getQnaDetail(int qnaId);
}