package com.sample.dao;

import java.util.List;

import com.sample.web.view.Reserve;

public interface ReserveDao {
    void insertReserve(Reserve reserve);
    List<Reserve> getReservesByUserId(String userId);
    List<Reserve> getAllReserves();
    Reserve getReserveDetail(int reserveId);
}